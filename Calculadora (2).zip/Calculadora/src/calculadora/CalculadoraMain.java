
package calculadora;


public class CalculadoraMain {
 public static void main(String[] args) {
		Calculadora calculadora = new Calculadora();
		calculadora.setVisible(true);
	}   
}
 